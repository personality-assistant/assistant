# content-for-telegtam-bot
kb_start = [
            [InlineKeyboardButton("Конкурсні предмети ЗНО", callback_data = "")],
            [InlineKeyboardButton("Розрахунок конкурсного балу", callback_data = "")],
            [InlineKeyboardButton("Етапи вступної кампанії", callback_data = "")],
            [InlineKeyboardButton("Корисні посилання", callback_data = "")],
            [InlineKeyboardButton("Кількість бюджетних та контрактних місць для вступників", callback_data = "")],
        ]
    reply = InlineKeyboardMarkup(kb_start)
   
